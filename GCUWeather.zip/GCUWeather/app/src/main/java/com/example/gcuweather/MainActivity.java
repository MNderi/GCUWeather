package com.example.gcuweather;

/*  Starter project for Mobile Platform Development in main diet 2023/2024
    You should use this project as the starting point for your assignment.
    This project simply reads the data from the required URL and displays the
    raw data in a TextField
*/

//
// Name                 _______Marthar Nderitu__________
// Student ID           _________________
// Programme of Study   ___Computing______________
//

// UPDATE THE PACKAGE NAME to include your Student Identifier

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class MainActivity extends AppCompatActivity implements OnClickListener {
    private TextView rawDataDisplay;
    private Button startButton;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rawDataDisplay = findViewById(R.id.welcomeMessage);
        startButton = findViewById(R.id.getStartedButton);
        startButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        openProgress();
    }

    public void openProgress() {
        Intent intent = new Intent(this, SearchActivity.class);
        startActivity(intent);
    }

}
