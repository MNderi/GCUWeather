package com.example.gcuweather;

import java.util.HashMap;
import java.util.Map;

public class CityDictionary {

    public static Map<String, String> getCityDictionary() {
        Map<String, String> cityDictionary = new HashMap<>();

        cityDictionary.put("Glasgow", "2648579");
        cityDictionary.put("London", "2643743");
        cityDictionary.put("New York", "5128581");
        cityDictionary.put("Oman", "287286");
        cityDictionary.put("Mauritius", "934154");
        cityDictionary.put("Bangladesh", "1185241");

        return cityDictionary;
    }
}

