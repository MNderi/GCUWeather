package com.example.gcuweather;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Map;

public class CityWeatherDetails extends AppCompatActivity {


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_city_weather_details);

        // Retrieve data from intent
        Intent intent = getIntent();
        String location = intent.getStringExtra("location");
        double temperature = intent.getDoubleExtra("Temperature", 0.0);
        String condition = intent.getStringExtra("Condition");

        // Find views in the layout
        TextView locationTextView = findViewById(R.id.locationTextView);
        ImageView weatherIcon = findViewById(R.id.weatherIcon);
        TextView temperatureTextView = findViewById(R.id.temperatureTextView);
        TextView conditionTextView = findViewById(R.id.conditionTextView);
        Button threedayforecast=findViewById(R.id.threedayforecast);
        ImageView backIcon= findViewById(R.id.backIcon);

        backIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentSearch=new Intent(v.getContext(),SearchActivity.class);
                startActivity(intentSearch);
            }
        });

        threedayforecast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inta=new Intent(v.getContext(),ThreedayForecast.class );
                inta.putExtra("location",location );
                startActivity(inta);
            }
        });

        // Set data to views
        locationTextView.setText(location);
        temperatureTextView.setText(" " + temperature + "°C");
        conditionTextView.setText(condition);

        // Load the appropriate weather icon based on the condition
        // For now, Using a placeholder
        weatherIcon.setImageResource(R.drawable.cloudyrainy);
    }
}