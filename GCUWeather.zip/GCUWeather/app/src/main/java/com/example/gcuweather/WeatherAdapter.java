package com.example.gcuweather;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class WeatherAdapter extends RecyclerView.Adapter<WeatherAdapter.ViewHolder> {

    private List<WeatherData> weatherDataList;
    private List<WeatherData> originalWeatherDataList;

    public WeatherAdapter(List<WeatherData> weatherDataList) {
        this.weatherDataList = weatherDataList;
        this.originalWeatherDataList = new ArrayList<>(weatherDataList);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.weather_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WeatherData weatherData = weatherDataList.get(position);
        String temperatureString = String.valueOf(weatherData.getTemperature());

        // Bind data to the ViewHolder
        holder.locationTextView.setText(weatherData.getTitle()); // Use getTitle() instead of getLocation()
        holder.temperatureTextView.setText(temperatureString);
        holder.conditionTextView.setText(weatherData.getDescription()); // Use getDescription() instead of getCondition()

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), CityWeatherDetails.class);
                intent.putExtra("location", weatherData.getTitle()); // Use getTitle() instead of getLocation()
                intent.putExtra("Temperature", weatherData.getTemperature());
                intent.putExtra("Condition", weatherData.getDescription()); // Use getDescription() instead of getCondition()
                v.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return weatherDataList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView locationTextView;
        TextView temperatureTextView;
        TextView conditionTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            locationTextView = itemView.findViewById(R.id.locationTextView);
            temperatureTextView = itemView.findViewById(R.id.temperatureTextView);
            conditionTextView = itemView.findViewById(R.id.conditionTextView);
        }
    }

    public void updateData(List<WeatherData> newData) {
        weatherDataList.clear();
        weatherDataList.addAll(newData);
        notifyDataSetChanged();
    }

    public void filterList(String text) {
        weatherDataList.clear();  // Clear the current data
        if (text.isEmpty()) {
            weatherDataList.addAll(originalWeatherDataList);  // If the search text is empty, show all data
        } else {
            // Filter data based on the search text
            text = text.toLowerCase(Locale.getDefault());
            for (WeatherData item : originalWeatherDataList) {
                if (item.getTitle().toLowerCase(Locale.getDefault()).contains(text) ||
                        String.valueOf(item.getTemperature()).toLowerCase(Locale.getDefault()).contains(text) ||
                        item.getDescription().toLowerCase(Locale.getDefault()).contains(text)) {
                    weatherDataList.add(item);
                }
            }
        }
        notifyDataSetChanged();  // Notify the adapter that the data has changed
    }
}
