package com.example.gcuweather;

import android.os.AsyncTask;
import android.util.Log;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DownloadXmlTask extends AsyncTask<Void, Void, List<WeatherData>> {

    private final String BASE_URL = "https://weather-service-thunder-broker.api.bbci.co.uk/en/observation/rss/";
    private WeatherAdapter weatherAdapter;

    public DownloadXmlTask(WeatherAdapter weatherAdapter) {
        this.weatherAdapter = weatherAdapter;
    }
    @Override
    protected List<WeatherData> doInBackground(Void... voids) {
        List<WeatherData> allWeatherData = new ArrayList<>();

        Map<String, String> cityDictionary = CityDictionary.getCityDictionary();

        for (Map.Entry<String, String> entry : cityDictionary.entrySet()) {
            String cityName = entry.getKey();
            String areaCode = entry.getValue();

            try {
                URL url = new URL(BASE_URL + areaCode);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = connection.getInputStream();

                List<WeatherData> cityWeatherData = XmlParser.parse(inputStream);

                if (cityWeatherData != null) {
                    allWeatherData.addAll(cityWeatherData);
                    Log.d("DownloadXmlTask", "Downloaded weather data for " + cityName);
                }

            } catch (Exception e) {
                Log.e("DownloadXmlTask", "Error downloading XML for " + cityName, e);
            }
        }

        return allWeatherData;
    }

    @Override
    protected void onPostExecute(List<WeatherData> weatherDataList) {
        // Process the combined weather data for all cities
        if (weatherDataList != null) {

                weatherAdapter.updateData(weatherDataList);

            for (WeatherData weatherData : weatherDataList) {
                Log.d("WeatherData", "Title: " + weatherData.getTitle());
                Log.d("WeatherData", "Link: " + weatherData.getLink());
                Log.d("WeatherData", "Description: " + weatherData.getDescription());
                Log.d("WeatherData", "PubDate: " + weatherData.getPubDate());
                Log.d("WeatherData", "Wind Direction: " + weatherData.getWindDirection());
                Log.d("WeatherData", "Temperature: " + weatherData.getTemperature());
                Log.d("WeatherData", "Humidity: " + weatherData.getHumidity());
                Log.d("WeatherData", "Pressure: " + weatherData.getPressure());
                Log.d("WeatherData", "Visibility: " + weatherData.getVisibility());
                Log.d("WeatherData", "--------------------------");
            }
        }
    }
}

